package co.agenciaviajes.negocio;

/**
 * Director Director que controla la creación paso a paso, solo cuando el Builder
 * ha terminado de construir el objeto lo recupera el Director
 *
 * @author Libardo Pantoja, Julio Hurtado, Ricardo Zambrano
 */
public class DirectorPlan {

    private PlanBuilder planBuilder;
    
    public  void setPlanBuilder( PlanBuilder pb){
        this.planBuilder=pb;
    }
    
    public Plan getPlan(){
        return this.planBuilder.plan;
    }
    
    public void construirPlan(){
        this.planBuilder.crearNuevoPlan();
       this.planBuilder.buildCliente();
       this.planBuilder.buildAlimentacion();
       this.planBuilder.buildAlojamientos();
       this.planBuilder.buildImpuestosTiquete();
       this.planBuilder.buildSeguroHotelero();
       this.planBuilder.buildTours();
       this.planBuilder.buildTrasportes();
       
    }
}
